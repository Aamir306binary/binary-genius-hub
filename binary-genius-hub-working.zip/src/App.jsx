
import React from 'react'

function App() {
  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center">
      <h1 className="text-3xl font-bold">🔥 Binary Genius Hub is Live!</h1>
    </div>
  )
}

export default App
