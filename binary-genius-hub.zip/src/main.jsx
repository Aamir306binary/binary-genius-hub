// main.jsx - React entry point
