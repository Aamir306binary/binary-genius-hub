// tailwind.config.js - Tailwind configuration
