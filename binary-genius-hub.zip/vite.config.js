// vite.config.js - Vite configuration
